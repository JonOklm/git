<?php

namespace App\Controller;

use App\Entity\Article;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ArticleController extends AbstractController
{
    #[Route('/articles', name: 'app_articles')]
    public function lesArticles(ManagerRegistry $doctrine): Response
    {
        // on recupere tous les articles depuis la bdd en passant par le repository lié à l'entité Article qui est (ArticleRepository) et on utilise la methode findAll() pour tout selectionner
        $articles = $doctrine->getRepository(Article::class)->findAll();

        //dd() permet de faire un dump et die a la fois (pour verifier le contenu d'une variable et arreter l'execution ici)
        dd($articles);

        return $this->render('article/index.html.twig', [
            'articles' => $articles
        ]);
    }
}
